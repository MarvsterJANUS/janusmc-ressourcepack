JANUS SERVER RESOURCE PACK (Minecraft 26.3, resource pack format 97)

All custom textures use custom_model_data strings on vanilla items, so players WITHOUT the pack still see a normal vanilla item.

TEXTURES (assets/janus/textures/...)  - replace freely, keep the file names (square PNGs, any size)
  item/logo.png                 JANUS logo (advancement tab, slot jackpot symbol)
  item/coin.png                 coin of the Double or Nothing machine            (base item: gold_block,  key janus_coin)
  item/token.png                token chip (cashier, icons)                      (base item: gold_nugget, key janus_token)
  item/card/0..51.png, back.png playing cards, index = rank*4 + suit (S,H,D,C)  (base item: paper,       key janus_card_<n> / janus_card_back)
  item/slot/cherry|bar|bell|diamond|seven|janus.png  slot reel symbols            (apple, emerald, gold_ingot, diamond, nether_star)
  font/token.png, font/logo.png chat icons for the characters ◉ and Ⓙ
  gui/advancements/backgrounds/janus.png   advancement tab background
SOUNDS (assets/janus/sounds/...)  - replace the .ogg files (mono!) to change them
  casino/coin, deal, spin, win, bigwin, jackpot, quest/complete, title/unlock

DISTRIBUTE (server.properties): resource-pack=<direct URL>, resource-pack-sha1=<SHA-1 of the zip>
