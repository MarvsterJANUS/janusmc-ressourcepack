JANUS SERVER RESOURCE PACK (Minecraft 26.3, resource pack format 97)

Contains the JANUS logo used as icon in the "JANUS" advancement tab.

REPLACE THE LOGO
  assets/janus/textures/item/logo.png                         -> your logo, square PNG (16x16, 32x32 or 64x64), transparent background
  assets/janus/textures/gui/advancements/backgrounds/janus.png -> background tile of the advancement tab (16x16)
  pack.png                                                    -> icon in the resource pack menu (optional)

DISTRIBUTE TO ALL PLAYERS (server.properties)
  resource-pack=<direct download URL of this zip>
  resource-pack-sha1=<SHA-1 of the zip>
  require-resource-pack=true
  resource-pack-prompt={"text":"The JANUS server pack shows our logo.","color":"gold"}
